// Profile page with working wallet connection
class ProfileApp {
    constructor() {
        this.walletConnection = window.walletConnection;
        this.userStore = window.userStore;
        this.currentUser = null;
        this.init();
    }

    async init() {
        this.setupEventListeners();
        await this.checkWalletConnectionAndLoadProfile();
    }

    setupEventListeners() {
        // Edit profile button
        document.addEventListener('click', (e) => {
            if (e.target.id === 'editProfileBtn') {
                this.showEditProfile();
            }
        });

        // Mobile menu toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileMenu = document.getElementById('mobileMenu');
        
        if (mobileMenuToggle && mobileMenu) {
            mobileMenuToggle.addEventListener('click', () => {
                mobileMenu.classList.toggle('active');
            });
            
            document.addEventListener('click', (e) => {
                if (!mobileMenuToggle.contains(e.target) && !mobileMenu.contains(e.target)) {
                    mobileMenu.classList.remove('active');
                }
            });
        }

        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
        });

        // Edit profile button
        const editBtn = document.getElementById('editProfileBtn');
        if (editBtn) {
            editBtn.addEventListener('click', () => this.toggleEditMode());
        }

        // Save profile button
        const saveBtn = document.getElementById('saveProfileBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.saveProfile());
        }
    }

    async checkWalletConnectionAndLoadProfile() {
        console.log('Profile: checkWalletConnectionAndLoadProfile called');
        
        // Check using direct wallet connection system
        if (window.walletState && window.walletState.isConnected && window.walletState.walletAddress) {
            const walletAddress = window.walletState.walletAddress;
            console.log('Profile: Wallet connected:', walletAddress);
            
            // Update wallet status display
            this.updateWalletStatus(walletAddress);
            
            // Check if user is registered as artist
            const isArtist = this.userStore.isArtistRegistered(walletAddress);
            
            if (isArtist) {
                this.currentUser = this.userStore.getArtist(walletAddress);
                this.showProfileContent();
                this.loadProfileData();
            } else {
                this.showArtistRegistrationPrompt();
            }
        } else {
            console.log('Profile: No wallet connection found - redirecting to main page');
            // Redirect to main page if no wallet connection
            window.location.href = '../../index.html';
        }
        
        // Update wallet UI
        if (window.walletConnection && window.walletConnection.updateUI) {
            window.walletConnection.updateUI();
        }
    }

    async handleWalletConnection() {
        console.log('Profile: handleWalletConnection called');
        
        // Use the direct wallet connection system
        if (window.walletState && window.walletState.isConnected) {
            // Already connected, disconnect
            if (window.disconnectWalletDirect) {
                window.disconnectWalletDirect();
            }
            this.showConnectWalletPrompt();
        } else {
            // Not connected, try to connect
            if (window.connectWalletDirect) {
                try {
                    await window.connectWalletDirect();
                    // Check if connection was successful
                    if (window.walletState && window.walletState.isConnected) {
                        this.showProfileContent();
                        this.loadProfileData();
                    }
                } catch (error) {
                    console.error('Profile: Wallet connection failed', error);
                }
            } else {
                console.error('Profile: Direct wallet connection not available');
            }
        }
    }

    updateWalletStatus(walletAddress) {
        const walletStatusElement = document.getElementById('walletAddress');
        if (walletStatusElement) {
            const shortAddress = `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`;
            walletStatusElement.textContent = shortAddress;
        }
    }

    showConnectWalletPrompt() {
        // Since we're redirecting to main page if no wallet, this shouldn't be called
        console.log('Profile: showConnectWalletPrompt called - redirecting to main page');
        window.location.href = '../../index.html';
    }

    showArtistRegistrationPrompt() {
        const profileContent = document.getElementById('profileContent');
        const welcomeSection = document.getElementById('welcomeSection');
        
        if (profileContent) profileContent.style.display = 'none';
        if (welcomeSection) {
            welcomeSection.style.display = 'block';
            welcomeSection.innerHTML = `
                <div class="registration-prompt">
                    <div class="prompt-content">
                        <h2>🎨 Artist Registration Required</h2>
                        <p>To access your profile, you need to register as an artist first.</p>
                        <p>Registration fee: <span class="price-converter" data-eth-amount="0.01" data-currency="kes">0.01 ETH</span></p>
                        <div class="rates-update-time"></div>
                        <button class="btn btn-primary" onclick="profileApp.showRegistrationForm()">Register as Artist</button>
                        <br><br>
                        <a href="artist-register.html" class="btn btn-secondary">Go to Registration Page</a>
                    </div>
                </div>
            `;
            
            // Update currency display
            if (window.currencyConverter) {
                window.currencyConverter.updateUI();
            }
        }
    }

    showRegistrationForm() {
        const connectWalletSection = document.getElementById('connectWalletSection');
        if (connectWalletSection) {
            connectWalletSection.style.display = 'none';
        }
        
        const profileContent = document.getElementById('profileContent');
        const artistForm = document.getElementById('artistProfileForm');
        
        if (profileContent) profileContent.style.display = 'block';
        if (artistForm) {
            artistForm.style.display = 'block';
            this.showEditMode();
        }
    }

    showProfileContent() {
        const profileContent = document.getElementById('profileContent');
        const welcomeSection = document.getElementById('welcomeSection');
        
        if (profileContent) profileContent.style.display = 'block';
        if (welcomeSection) welcomeSection.style.display = 'none';
    }

    showEditProfile() {
        console.log('Profile: showEditProfile called');
        
        // Hide welcome section and show profile content
        const welcomeSection = document.getElementById('welcomeSection');
        const profileContent = document.getElementById('profileContent');
        
        if (welcomeSection) welcomeSection.style.display = 'none';
        if (profileContent) profileContent.style.display = 'block';
        
        // Enable edit mode
        this.toggleEditMode();
    }

    loadProfileData() {
        const walletAddress = window.walletState && window.walletState.walletAddress;
        
        if (walletAddress && this.currentUser) {
            // Update wallet address displays
            const userAddress = document.getElementById('userAddress');
            const userAddressDisplay = document.getElementById('userAddressDisplay');
            const userInitials = document.getElementById('userInitials');
            
            if (userAddress) {
                userAddress.textContent = this.currentUser.name || `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`;
            }
            if (userAddressDisplay) {
                userAddressDisplay.textContent = walletAddress;
            }
            if (userInitials) {
                userInitials.textContent = this.currentUser.name ? this.currentUser.name.charAt(0).toUpperCase() : '?';
            }
            
            // Load form data
            this.loadFormData();
        }

        // Load user NFTs and stats
        this.loadUserNFTs();
        this.loadUserStats();
    }

    loadFormData() {
        if (!this.currentUser) return;
        
        const fields = [
            'artistName', 'artistBio', 'artistWebsite', 
            'artistSocial', 'artistEmail', 'artistLocation'
        ];
        
        fields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                const dataKey = fieldId.replace('artist', '').toLowerCase();
                field.value = this.currentUser[dataKey] || '';
            }
        });
    }

    loadUserNFTs() {
        const nftGrid = document.getElementById('userNFTGrid');
        if (!nftGrid) return;

        const walletAddress = this.walletConnection.getWalletAddress();
        const userNFTs = this.userStore.getUserNFTs(walletAddress);

        if (userNFTs.length === 0) {
            nftGrid.innerHTML = `
                <div class="empty-state">
                    <h3>No NFTs yet</h3>
                    <p>Create your first NFT to get started!</p>
                    <a href="upload.html" class="btn btn-primary">Create NFT</a>
                </div>
            `;
            return;
        }

        nftGrid.innerHTML = userNFTs.map(nft => `
            <div class="nft-card">
                <div class="nft-image">
                    ${this.renderNFTImage(nft)}
                    ${nft.forSale ? '<span class="sale-badge">For Sale</span>' : ''}
                    ${nft.sold ? '<span class="sold-badge">Sold</span>' : ''}
                </div>
                <div class="nft-info">
                    <h4>${nft.name}</h4>
                    <div class="price-converter" data-eth-amount="${nft.price}" data-currency="kes">
                        ${nft.price} ETH
                    </div>
                    ${!nft.sold ? `
                        <button class="btn btn-small ${nft.forSale ? 'btn-secondary' : 'btn-primary'}" 
                                onclick="profileApp.toggleSaleStatus('${nft.id}', ${!nft.forSale})">
                            ${nft.forSale ? 'Remove from Sale' : 'Put on Sale'}
                        </button>
                    ` : '<span class="sold-status">Sold</span>'}
                </div>
            </div>
        `).join('');
        
        // Update currency displays
        if (window.currencyConverter) {
            window.currencyConverter.updateUI();
        }
    }

    generateNFTImage(id, name) {
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD'];
        const color = colors[id % colors.length];
        
        return `
            <div style="
                width: 100%;
                height: 200px;
                background: linear-gradient(135deg, ${color} 0%, ${color}88 100%);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-weight: bold;
                font-size: 2rem;
                border-radius: 8px;
            ">
                🎨
            </div>
        `;
    }

    loadUserStats() {
        const totalNFTs = document.getElementById('totalNFTs');
        const totalSales = document.getElementById('totalSales');
        const totalEarnings = document.getElementById('totalEarnings');

        if (this.currentUser) {
            const userNFTs = this.userStore.getUserNFTs(this.currentUser.walletAddress);
            const soldNFTs = userNFTs.filter(nft => nft.sold);
            
            if (totalNFTs) totalNFTs.textContent = userNFTs.length.toString();
            if (totalSales) totalSales.textContent = soldNFTs.length.toString();
            if (totalEarnings) {
                const earnings = this.currentUser.totalEarnings || '0';
                totalEarnings.innerHTML = `
                    <div class="price-converter" data-eth-amount="${earnings}" data-currency="kes">
                        ${earnings} ETH
                    </div>
                `;
            }
        }
        
        // Update currency displays
        if (window.currencyConverter) {
            window.currencyConverter.updateUI();
        }
    }

    renderNFTImage(nft) {
        if (nft.image) {
            // Use stored image
            const imageData = window.imageHandler.getImage(nft.image);
            if (imageData) {
                return `<img src="${imageData.data}" alt="${nft.name}" style="width: 100%; height: 200px; object-fit: cover;">`;
            }
        }
        
        // Fallback to generated image
        return this.generateNFTImage(nft.id, nft.name);
    }

    switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        const activeTab = document.getElementById(`${tabName}Tab`);
        if (activeTab) activeTab.classList.add('active');
    }

    toggleEditMode() {
        const artistForm = document.getElementById('artistProfileForm');
        const editBtn = document.getElementById('editProfileBtn');
        const saveBtn = document.getElementById('saveProfileBtn');
        
        if (artistForm) {
            const isEditing = artistForm.style.display !== 'none';
            
            if (isEditing) {
                // Hide form and show view mode
                artistForm.style.display = 'none';
                if (editBtn) editBtn.style.display = 'block';
                if (saveBtn) saveBtn.style.display = 'none';
                
                // Disable all editable fields
                const editableFields = document.querySelectorAll('.editable');
                editableFields.forEach(field => {
                    field.disabled = true;
                });
            } else {
                // Show form and enter edit mode
                this.showEditMode();
            }
        }
    }

    showEditMode() {
        const artistForm = document.getElementById('artistProfileForm');
        const editBtn = document.getElementById('editProfileBtn');
        const saveBtn = document.getElementById('saveProfileBtn');
        
        if (artistForm) {
            artistForm.style.display = 'block';
            if (editBtn) editBtn.style.display = 'none';
            if (saveBtn) saveBtn.style.display = 'block';
            
            // Enable all editable fields
            const editableFields = document.querySelectorAll('.editable');
            editableFields.forEach(field => {
                field.disabled = false;
            });
            
            // Load current data
            this.loadFormData();
        }
    }

    saveProfile() {
        const walletAddress = this.walletConnection.getWalletAddress();
        const artistName = document.getElementById('artistName')?.value;
        const artistBio = document.getElementById('artistBio')?.value;
        const artistWebsite = document.getElementById('artistWebsite')?.value;
        const artistSocial = document.getElementById('artistSocial')?.value;
        const artistEmail = document.getElementById('artistEmail')?.value;
        const artistLocation = document.getElementById('artistLocation')?.value;
        
        if (!artistName || !artistBio) {
            this.walletConnection.showMessage('Please fill in all required fields (Name and Bio).', 'error');
            return;
        }
        
        // Validate email if provided
        if (artistEmail && !this.isValidEmail(artistEmail)) {
            this.walletConnection.showMessage('Please enter a valid email address.', 'error');
            return;
        }
        
        // Validate website if provided
        if (artistWebsite && !this.isValidUrl(artistWebsite)) {
            this.walletConnection.showMessage('Please enter a valid website URL.', 'error');
            return;
        }
        
        // Check if this is a new registration (registration fee required)
        const isNewRegistration = !this.userStore.isArtistRegistered(walletAddress);
        
        if (isNewRegistration) {
            // Simulate registration fee payment
            this.processRegistrationFee(walletAddress, {
                name: artistName,
                bio: artistBio,
                website: artistWebsite,
                social: artistSocial,
                email: artistEmail,
                location: artistLocation
            });
        } else {
            // Update existing artist
            const updatedData = {
                name: artistName,
                bio: artistBio,
                website: artistWebsite,
                social: artistSocial,
                email: artistEmail,
                location: artistLocation
            };
            
            this.userStore.registerArtist(walletAddress, updatedData);
            this.currentUser = this.userStore.getArtist(walletAddress);
            
            this.walletConnection.showMessage('Profile updated successfully!', 'success');
            this.toggleEditMode();
            this.loadProfileData();
        }
    }

    async processRegistrationFee(walletAddress, artistData) {
        try {
            // Show registration fee processing
            this.walletConnection.showMessage('Processing registration fee (0.01 ETH)...', 'info');
            
            // Simulate blockchain transaction
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Register the artist
            this.userStore.registerArtist(walletAddress, artistData);
            this.currentUser = this.userStore.getArtist(walletAddress);
            
            this.walletConnection.showMessage('Artist registration successful! Registration fee: 0.01 ETH', 'success');
            this.toggleEditMode();
            this.loadProfileData();
            
        } catch (error) {
            this.walletConnection.showMessage('Registration failed. Please try again.', 'error');
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    isValidUrl(url) {
        try {
            new URL(url);
            return true;
        } catch (e) {
            return false;
        }
    }

    toggleSaleStatus(nftId, forSale) {
        const walletAddress = this.walletConnection.getWalletAddress();
        const result = this.userStore.toggleNFTSale(nftId, walletAddress);
        
        if (result) {
            this.walletConnection.showMessage(
                `NFT ${result.forSale ? 'put on sale' : 'removed from sale'} successfully!`, 
                'success'
            );
            
            // Reload NFTs and stats
            this.loadUserNFTs();
            this.loadUserStats();
        } else {
            this.walletConnection.showMessage('Failed to update NFT status.', 'error');
        }
    }
}

// Initialize profile app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.profileApp = new ProfileApp();
});
