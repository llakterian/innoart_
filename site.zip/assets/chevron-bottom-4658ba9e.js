import{s as o}from"./core-d371c30b.js";import"./main-2e39aaab.js";/* empty css               */import"./events-73379f27.js";import"./index.es-85995982.js";const e=o`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1.46 4.96a1 1 0 0 1 1.41 0L8 10.09l5.13-5.13a1 1 0 1 1 1.41 1.41l-5.83 5.84a1 1 0 0 1-1.42 0L1.46 6.37a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`;export{e as chevronBottomSvg};
