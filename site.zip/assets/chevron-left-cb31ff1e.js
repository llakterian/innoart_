import{s as o}from"./core-d371c30b.js";import"./main-2e39aaab.js";/* empty css               */import"./events-73379f27.js";import"./index.es-85995982.js";const e=o`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M11.04 1.46a1 1 0 0 1 0 1.41L5.91 8l5.13 5.13a1 1 0 1 1-1.41 1.41L3.79 8.71a1 1 0 0 1 0-1.42l5.84-5.83a1 1 0 0 1 1.41 0Z"
    clip-rule="evenodd"
  />
</svg>`;export{e as chevronLeftSvg};
