var t,e;import{z as i,B as r,c as o,r as a,L as s,h as n,n as l,D as c,m as p,e as h}from"./core-d371c30b.js";import{_ as d}from"./main-2e39aaab.js";const _={getSpacingStyles:(t,e)=>Array.isArray(t)?t[e]?`var(--wui-spacing-${t[e]})`:void 0:"string"==typeof t?`var(--wui-spacing-${t})`:void 0,getFormattedDate:t=>new Intl.DateTimeFormat("en-US",{month:"short",day:"numeric"}).format(t),getHostName(t){try{return new URL(t).hostname}catch(e){return""}},getTruncateString:({string:t,charsStart:e,charsEnd:i,truncate:r})=>t.length<=e+i?t:"end"===r?`${t.substring(0,e)}...`:"start"===r?`...${t.substring(t.length-i)}`:`${t.substring(0,Math.floor(e))}...${t.substring(t.length-Math.floor(i))}`,generateAvatarColors(t){const e=t.toLowerCase().replace(/^0x/iu,"").replace(/[^a-f0-9]/gu,"").substring(0,6).padEnd(6,"0"),i=this.hexToRgb(e),r=getComputedStyle(document.documentElement).getPropertyValue("--w3m-border-radius-master"),o=100-3*Number(null==r?void 0:r.replace("px","")),a=`${o}% ${o}% at 65% 40%`,s=[];for(let n=0;n<5;n+=1){const t=this.tintColor(i,.15*n);s.push(`rgb(${t[0]}, ${t[1]}, ${t[2]})`)}return`\n    --local-color-1: ${s[0]};\n    --local-color-2: ${s[1]};\n    --local-color-3: ${s[2]};\n    --local-color-4: ${s[3]};\n    --local-color-5: ${s[4]};\n    --local-radial-circle: ${a}\n   `},hexToRgb(t){const e=parseInt(t,16);return[e>>16&255,e>>8&255,255&e]},tintColor(t,e){const[i,r,o]=t;return[Math.round(i+(255-i)*e),Math.round(r+(255-r)*e),Math.round(o+(255-o)*e)]},isNumber:t=>/^[0-9]+$/u.test(t),getColorTheme(t){var e;return t||("undefined"!=typeof window&&window.matchMedia?(null==(e=window.matchMedia("(prefers-color-scheme: dark)"))?void 0:e.matches)?"dark":"light":"dark")},splitBalance(t){const e=t.split(".");return 2===e.length?[e[0],e[1]]:["0","00"]},roundNumber:(t,e,i)=>t.toString().length>=e?Number(t).toFixed(i):t,formatNumberToLocalString:(t,e=2)=>void 0===t?"0.00":"number"==typeof t?t.toLocaleString("en-US",{maximumFractionDigits:e,minimumFractionDigits:e}):parseFloat(t).toLocaleString("en-US",{maximumFractionDigits:e,minimumFractionDigits:e})};function u(t){return function(e){return"function"==typeof e?function(t,e){return customElements.get(t)||customElements.define(t,e),e}(t,e):function(t,e){const{kind:i,elements:r}=e;return{kind:i,elements:r,finisher(e){customElements.get(t)||customElements.define(t,e)}}}(t,e)}}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let m;globalThis.litIssuedWarnings??(globalThis.litIssuedWarnings=new Set),m=(t,e)=>{e+=` See https://lit.dev/msg/${t} for more information.`,globalThis.litIssuedWarnings.has(e)||globalThis.litIssuedWarnings.has(t)||(console.warn(e),globalThis.litIssuedWarnings.add(e))};const g={attribute:!0,type:String,converter:i,reflect:!1,hasChanged:r},w=(t=g,e,i)=>{const{kind:r,metadata:o}=i;null==o&&m("missing-class-metadata",`The class ${e} is missing decorator metadata. This could mean that you're using a compiler that supports decorators but doesn't support decorator metadata, such as TypeScript 5.1. Please update your compiler.`);let a=globalThis.litPropertyMetadata.get(o);if(void 0===a&&globalThis.litPropertyMetadata.set(o,a=new Map),"setter"===r&&((t=Object.create(t)).wrapped=!0),a.set(i.name,t),"accessor"===r){const{name:r}=i;return{set(i){const o=e.get.call(this);e.set.call(this,i),this.requestUpdate(r,o,t)},init(e){return void 0!==e&&this._$changeProperty(r,void 0,t,e),e}}}if("setter"===r){const{name:r}=i;return function(i){const o=this[r];e.call(this,i),this.requestUpdate(r,o,t)}}throw new Error(`Unsupported decorator location: ${r}`)};function v(t){return(e,i)=>"object"==typeof i?w(t,e,i):((t,e,i)=>{const r=e.hasOwnProperty(i);return e.constructor.createProperty(i,t),r?Object.getOwnPropertyDescriptor(e,i):void 0})(t,e,i)}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function f(t){return v({...t,state:!0,attribute:!1})}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */globalThis.litIssuedWarnings??(globalThis.litIssuedWarnings=new Set);const y=o`
  :host {
    display: flex;
    width: inherit;
    height: inherit;
  }
`;var b=globalThis&&globalThis.__decorate||function(t,e,i,r){var o,a=arguments.length,s=a<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(t,e,i,r);else for(var n=t.length-1;n>=0;n--)(o=t[n])&&(s=(a<3?o(s):a>3?o(e,i,s):o(e,i))||s);return a>3&&s&&Object.defineProperty(e,i,s),s};let E=class extends s{render(){return this.style.cssText=`\n      flex-direction: ${this.flexDirection};\n      flex-wrap: ${this.flexWrap};\n      flex-basis: ${this.flexBasis};\n      flex-grow: ${this.flexGrow};\n      flex-shrink: ${this.flexShrink};\n      align-items: ${this.alignItems};\n      justify-content: ${this.justifyContent};\n      column-gap: ${this.columnGap&&`var(--wui-spacing-${this.columnGap})`};\n      row-gap: ${this.rowGap&&`var(--wui-spacing-${this.rowGap})`};\n      gap: ${this.gap&&`var(--wui-spacing-${this.gap})`};\n      padding-top: ${this.padding&&_.getSpacingStyles(this.padding,0)};\n      padding-right: ${this.padding&&_.getSpacingStyles(this.padding,1)};\n      padding-bottom: ${this.padding&&_.getSpacingStyles(this.padding,2)};\n      padding-left: ${this.padding&&_.getSpacingStyles(this.padding,3)};\n      margin-top: ${this.margin&&_.getSpacingStyles(this.margin,0)};\n      margin-right: ${this.margin&&_.getSpacingStyles(this.margin,1)};\n      margin-bottom: ${this.margin&&_.getSpacingStyles(this.margin,2)};\n      margin-left: ${this.margin&&_.getSpacingStyles(this.margin,3)};\n    `,n`<slot></slot>`}};E.styles=[a,y],b([v()],E.prototype,"flexDirection",void 0),b([v()],E.prototype,"flexWrap",void 0),b([v()],E.prototype,"flexBasis",void 0),b([v()],E.prototype,"flexGrow",void 0),b([v()],E.prototype,"flexShrink",void 0),b([v()],E.prototype,"alignItems",void 0),b([v()],E.prototype,"justifyContent",void 0),b([v()],E.prototype,"columnGap",void 0),b([v()],E.prototype,"rowGap",void 0),b([v()],E.prototype,"gap",void 0),b([v()],E.prototype,"padding",void 0),b([v()],E.prototype,"margin",void 0),E=b([u("wui-flex")],E);
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const T=t=>t??l;
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */(null==(t=window.ShadyDOM)?void 0:t.inUse)&&!0===(null==(e=window.ShadyDOM)?void 0:e.noPatch)&&window.ShadyDOM.wrap;const x=1,S=2,j=t=>(...e)=>({_$litDirective$:t,values:e});class R{constructor(t){}get _$isConnected(){return this._$parent._$isConnected}_$initialize(t,e,i){this.__part=t,this._$parent=e,this.__attributeIndex=i}_$resolve(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const P=(t,e)=>{var i;const r=t._$disconnectableChildren;if(void 0===r)return!1;for(const o of r)null==(i=o._$notifyDirectiveConnectionChanged)||i.call(o,e,!1),P(o,e);return!0},$=t=>{let e,i;do{if(void 0===(e=t._$parent))break;i=e._$disconnectableChildren,i.delete(t),t=e}while(0===(null==i?void 0:i.size))},O=t=>{for(let e;e=t._$parent;t=e){let i=e._$disconnectableChildren;if(void 0===i)e._$disconnectableChildren=i=new Set;else if(i.has(t))break;i.add(t),k(e)}};function I(t){void 0!==this._$disconnectableChildren?($(this),this._$parent=t,O(this)):this._$parent=t}function D(t,e=!1,i=0){const r=this._$committedValue,o=this._$disconnectableChildren;if(void 0!==o&&0!==o.size)if(e)if(Array.isArray(r))for(let a=i;a<r.length;a++)P(r[a],!1),$(r[a]);else null!=r&&(P(r,!1),$(r));else P(this,t)}const k=t=>{t.type==S&&(t._$notifyConnectionChanged??(t._$notifyConnectionChanged=D),t._$reparentDisconnectables??(t._$reparentDisconnectables=I))};class L extends R{constructor(){super(...arguments),this._$disconnectableChildren=void 0}_$initialize(t,e,i){super._$initialize(t,e,i),O(this),this.isConnected=t._$isConnected}_$notifyDirectiveConnectionChanged(t,e=!0){var i,r;t!==this.isConnected&&(this.isConnected=t,t?null==(i=this.reconnected)||i.call(this):null==(r=this.disconnected)||r.call(this)),e&&(P(this,t),$(this))}setValue(t){if(void 0===this.__part.strings)this.__part._$setValue(t,this);else{if(void 0===this.__attributeIndex)throw new Error("Expected this.__attributeIndex to be a number");const e=[...this.__part._$committedValue];e[this.__attributeIndex]=t,this.__part._$setValue(e,this,0)}}disconnected(){}reconnected(){}}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class z{constructor(t){this._ref=t}disconnect(){this._ref=void 0}reconnect(t){this._ref=t}deref(){return this._ref}}class V{constructor(){this._promise=void 0,this._resolve=void 0}get(){return this._promise}pause(){this._promise??(this._promise=new Promise(t=>this._resolve=t))}resume(){var t;null==(t=this._resolve)||t.call(this),this._promise=this._resolve=void 0}}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const A=t=>{return!(e=t,null===e||"object"!=typeof e&&"function"!=typeof e||"function"!=typeof t.then);var e},C=1073741823;const B=j(class extends L{constructor(){super(...arguments),this.__lastRenderedIndex=C,this.__values=[],this.__weakThis=new z(this),this.__pauser=new V}render(...t){return t.find(t=>!A(t))??c}update(t,e){const i=this.__values;let r=i.length;this.__values=e;const o=this.__weakThis,a=this.__pauser;this.isConnected||this.disconnected();for(let s=0;s<e.length&&!(s>this.__lastRenderedIndex);s++){const t=e[s];if(!A(t))return this.__lastRenderedIndex=s,t;s<r&&t===i[s]||(this.__lastRenderedIndex=C,r=0,Promise.resolve(t).then(async e=>{for(;a.get();)await a.get();const i=o.deref();if(void 0!==i){const r=i.__values.indexOf(t);r>-1&&r<i.__lastRenderedIndex&&(i.__lastRenderedIndex=r,i.setValue(e))}}))}return c}disconnected(){this.__weakThis.disconnect(),this.__pauser.pause()}reconnected(){this.__weakThis.reconnect(this),this.__pauser.resume()}});const M=new class{constructor(){this.cache=new Map}set(t,e){this.cache.set(t,e)}get(t){return this.cache.get(t)}has(t){return this.cache.has(t)}delete(t){this.cache.delete(t)}clear(){this.cache.clear()}},H=o`
  :host {
    display: flex;
    aspect-ratio: var(--local-aspect-ratio);
    color: var(--local-color);
    width: var(--local-width);
  }

  svg {
    width: inherit;
    height: inherit;
    object-fit: contain;
    object-position: center;
  }

  .fallback {
    width: var(--local-width);
    height: var(--local-height);
  }
`;var W=globalThis&&globalThis.__decorate||function(t,e,i,r){var o,a=arguments.length,s=a<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(t,e,i,r);else for(var n=t.length-1;n>=0;n--)(o=t[n])&&(s=(a<3?o(s):a>3?o(e,i,s):o(e,i))||s);return a>3&&s&&Object.defineProperty(e,i,s),s};const F={add:async()=>(await d(()=>import("./add-fdafe2b8.js"),["./add-fdafe2b8.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).addSvg,allWallets:async()=>(await d(()=>import("./all-wallets-b4d1eeec.js"),["./all-wallets-b4d1eeec.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).allWalletsSvg,arrowBottomCircle:async()=>(await d(()=>import("./arrow-bottom-circle-b402f7ee.js"),["./arrow-bottom-circle-b402f7ee.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).arrowBottomCircleSvg,appStore:async()=>(await d(()=>import("./app-store-a4425b3d.js"),["./app-store-a4425b3d.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).appStoreSvg,apple:async()=>(await d(()=>import("./apple-364fc06f.js"),["./apple-364fc06f.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).appleSvg,arrowBottom:async()=>(await d(()=>import("./arrow-bottom-3492f8f8.js"),["./arrow-bottom-3492f8f8.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).arrowBottomSvg,arrowLeft:async()=>(await d(()=>import("./arrow-left-faa63339.js"),["./arrow-left-faa63339.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).arrowLeftSvg,arrowRight:async()=>(await d(()=>import("./arrow-right-cb1d5d39.js"),["./arrow-right-cb1d5d39.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).arrowRightSvg,arrowTop:async()=>(await d(()=>import("./arrow-top-3ce40403.js"),["./arrow-top-3ce40403.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).arrowTopSvg,bank:async()=>(await d(()=>import("./bank-ed2d672e.js"),["./bank-ed2d672e.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).bankSvg,browser:async()=>(await d(()=>import("./browser-cc6c83cf.js"),["./browser-cc6c83cf.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).browserSvg,card:async()=>(await d(()=>import("./card-5013bf52.js"),["./card-5013bf52.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).cardSvg,checkmark:async()=>(await d(()=>import("./checkmark-32166cd0.js"),["./checkmark-32166cd0.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).checkmarkSvg,checkmarkBold:async()=>(await d(()=>import("./checkmark-bold-4aeb3bdc.js"),["./checkmark-bold-4aeb3bdc.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).checkmarkBoldSvg,chevronBottom:async()=>(await d(()=>import("./chevron-bottom-4658ba9e.js"),["./chevron-bottom-4658ba9e.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).chevronBottomSvg,chevronLeft:async()=>(await d(()=>import("./chevron-left-cb31ff1e.js"),["./chevron-left-cb31ff1e.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).chevronLeftSvg,chevronRight:async()=>(await d(()=>import("./chevron-right-2782219e.js"),["./chevron-right-2782219e.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).chevronRightSvg,chevronTop:async()=>(await d(()=>import("./chevron-top-f7182eba.js"),["./chevron-top-f7182eba.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).chevronTopSvg,chromeStore:async()=>(await d(()=>import("./chrome-store-f42d9687.js"),["./chrome-store-f42d9687.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).chromeStoreSvg,clock:async()=>(await d(()=>import("./clock-b67e8a67.js"),["./clock-b67e8a67.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).clockSvg,close:async()=>(await d(()=>import("./close-e593b4ea.js"),["./close-e593b4ea.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).closeSvg,compass:async()=>(await d(()=>import("./compass-efbbcde6.js"),["./compass-efbbcde6.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).compassSvg,coinPlaceholder:async()=>(await d(()=>import("./coinPlaceholder-6eaa4c57.js"),["./coinPlaceholder-6eaa4c57.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).coinPlaceholderSvg,copy:async()=>(await d(()=>import("./copy-2037d6f7.js"),["./copy-2037d6f7.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).copySvg,cursor:async()=>(await d(()=>import("./cursor-c1c492b1.js"),["./cursor-c1c492b1.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).cursorSvg,cursorTransparent:async()=>(await d(()=>import("./cursor-transparent-ad10eca2.js"),["./cursor-transparent-ad10eca2.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).cursorTransparentSvg,desktop:async()=>(await d(()=>import("./desktop-6ad0b5e1.js"),["./desktop-6ad0b5e1.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).desktopSvg,disconnect:async()=>(await d(()=>import("./disconnect-f45fcf34.js"),["./disconnect-f45fcf34.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).disconnectSvg,discord:async()=>(await d(()=>import("./discord-6b85f402.js"),["./discord-6b85f402.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).discordSvg,etherscan:async()=>(await d(()=>import("./etherscan-0665c62f.js"),["./etherscan-0665c62f.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).etherscanSvg,extension:async()=>(await d(()=>import("./extension-ff95d88b.js"),["./extension-ff95d88b.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).extensionSvg,externalLink:async()=>(await d(()=>import("./external-link-6b837740.js"),["./external-link-6b837740.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).externalLinkSvg,facebook:async()=>(await d(()=>import("./facebook-2166ee8c.js"),["./facebook-2166ee8c.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).facebookSvg,farcaster:async()=>(await d(()=>import("./farcaster-32cf35ae.js"),["./farcaster-32cf35ae.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).farcasterSvg,filters:async()=>(await d(()=>import("./filters-fd7fe043.js"),["./filters-fd7fe043.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).filtersSvg,github:async()=>(await d(()=>import("./github-e8d47121.js"),["./github-e8d47121.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).githubSvg,google:async()=>(await d(()=>import("./google-408e9390.js"),["./google-408e9390.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).googleSvg,helpCircle:async()=>(await d(()=>import("./help-circle-99f7d200.js"),["./help-circle-99f7d200.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).helpCircleSvg,image:async()=>(await d(()=>import("./image-47329f61.js"),["./image-47329f61.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).imageSvg,id:async()=>(await d(()=>import("./id-1bb858c5.js"),["./id-1bb858c5.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).idSvg,infoCircle:async()=>(await d(()=>import("./info-circle-74db6cba.js"),["./info-circle-74db6cba.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).infoCircleSvg,lightbulb:async()=>(await d(()=>import("./lightbulb-2295e7f2.js"),["./lightbulb-2295e7f2.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).lightbulbSvg,mail:async()=>(await d(()=>import("./mail-0ca759f4.js"),["./mail-0ca759f4.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).mailSvg,mobile:async()=>(await d(()=>import("./mobile-f5321a54.js"),["./mobile-f5321a54.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).mobileSvg,more:async()=>(await d(()=>import("./more-c06e9795.js"),["./more-c06e9795.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).moreSvg,networkPlaceholder:async()=>(await d(()=>import("./network-placeholder-5a7a5a8e.js"),["./network-placeholder-5a7a5a8e.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).networkPlaceholderSvg,nftPlaceholder:async()=>(await d(()=>import("./nftPlaceholder-3adb7e6c.js"),["./nftPlaceholder-3adb7e6c.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).nftPlaceholderSvg,off:async()=>(await d(()=>import("./off-c6ccb913.js"),["./off-c6ccb913.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).offSvg,playStore:async()=>(await d(()=>import("./play-store-4c90e9df.js"),["./play-store-4c90e9df.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).playStoreSvg,plus:async()=>(await d(()=>import("./plus-955d099d.js"),["./plus-955d099d.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).plusSvg,qrCode:async()=>(await d(()=>import("./qr-code-dcc9c5ff.js"),["./qr-code-dcc9c5ff.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).qrCodeIcon,recycleHorizontal:async()=>(await d(()=>import("./recycle-horizontal-481f40ab.js"),["./recycle-horizontal-481f40ab.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).recycleHorizontalSvg,refresh:async()=>(await d(()=>import("./refresh-ea3ed1bc.js"),["./refresh-ea3ed1bc.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).refreshSvg,search:async()=>(await d(()=>import("./search-d94bba53.js"),["./search-d94bba53.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).searchSvg,send:async()=>(await d(()=>import("./send-accc84fb.js"),["./send-accc84fb.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).sendSvg,swapHorizontal:async()=>(await d(()=>import("./swapHorizontal-7711cb21.js"),["./swapHorizontal-7711cb21.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).swapHorizontalSvg,swapHorizontalMedium:async()=>(await d(()=>import("./swapHorizontalMedium-d981f3db.js"),["./swapHorizontalMedium-d981f3db.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).swapHorizontalMediumSvg,swapHorizontalBold:async()=>(await d(()=>import("./swapHorizontalBold-fac03eb1.js"),["./swapHorizontalBold-fac03eb1.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).swapHorizontalBoldSvg,swapHorizontalRoundedBold:async()=>(await d(()=>import("./swapHorizontalRoundedBold-d8f5d98b.js"),["./swapHorizontalRoundedBold-d8f5d98b.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).swapHorizontalRoundedBoldSvg,swapVertical:async()=>(await d(()=>import("./swapVertical-c81c4d77.js"),["./swapVertical-c81c4d77.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).swapVerticalSvg,telegram:async()=>(await d(()=>import("./telegram-67281ad7.js"),["./telegram-67281ad7.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).telegramSvg,threeDots:async()=>(await d(()=>import("./three-dots-e1af0e41.js"),["./three-dots-e1af0e41.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).threeDotsSvg,twitch:async()=>(await d(()=>import("./twitch-594639b9.js"),["./twitch-594639b9.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).twitchSvg,twitter:async()=>(await d(()=>import("./x-413574c3.js"),["./x-413574c3.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).xSvg,twitterIcon:async()=>(await d(()=>import("./twitterIcon-82a71056.js"),["./twitterIcon-82a71056.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).twitterIconSvg,verify:async()=>(await d(()=>import("./verify-c45fb6cd.js"),["./verify-c45fb6cd.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).verifySvg,verifyFilled:async()=>(await d(()=>import("./verify-filled-efb4c861.js"),["./verify-filled-efb4c861.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).verifyFilledSvg,wallet:async()=>(await d(()=>import("./wallet-1d967e61.js"),["./wallet-1d967e61.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).walletSvg,walletConnect:async()=>(await d(()=>import("./walletconnect-139d887c.js"),["./walletconnect-139d887c.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).walletConnectSvg,walletConnectLightBrown:async()=>(await d(()=>import("./walletconnect-139d887c.js"),["./walletconnect-139d887c.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).walletConnectLightBrownSvg,walletConnectBrown:async()=>(await d(()=>import("./walletconnect-139d887c.js"),["./walletconnect-139d887c.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).walletConnectBrownSvg,walletPlaceholder:async()=>(await d(()=>import("./wallet-placeholder-fe035633.js"),["./wallet-placeholder-fe035633.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).walletPlaceholderSvg,warningCircle:async()=>(await d(()=>import("./warning-circle-6a4f5a0b.js"),["./warning-circle-6a4f5a0b.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).warningCircleSvg,x:async()=>(await d(()=>import("./x-413574c3.js"),["./x-413574c3.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).xSvg,info:async()=>(await d(()=>import("./info-34632554.js"),["./info-34632554.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).infoSvg,exclamationTriangle:async()=>(await d(()=>import("./exclamation-triangle-64248f14.js"),["./exclamation-triangle-64248f14.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).exclamationTriangleSvg,reown:async()=>(await d(()=>import("./reown-logo-98b7f85f.js"),["./reown-logo-98b7f85f.js","./core-d371c30b.js","./main-2e39aaab.js","./global-38c848b6.css","./events-73379f27.js","./index.es-85995982.js"],import.meta.url)).reownSvg};let U=class extends s{constructor(){super(...arguments),this.size="md",this.name="copy",this.color="fg-300",this.aspectRatio="1 / 1"}render(){return this.style.cssText=`\n      --local-color: var(--wui-color-${this.color});\n      --local-width: var(--wui-icon-size-${this.size});\n      --local-aspect-ratio: ${this.aspectRatio}\n    `,n`${B(async function(t){if(M.has(t))return M.get(t);const e=(F[t]??F.copy)();return M.set(t,e),e}(this.name),n`<div class="fallback"></div>`)}`}};U.styles=[a,p,H],W([v()],U.prototype,"size",void 0),W([v()],U.prototype,"name",void 0),W([v()],U.prototype,"color",void 0),W([v()],U.prototype,"aspectRatio",void 0),U=W([u("wui-icon")],U);const G=j(
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
class extends R{constructor(t){var e;if(super(t),t.type!==x||"class"!==t.name||(null==(e=t.strings)?void 0:e.length)>2)throw new Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(t){return" "+Object.keys(t).filter(e=>t[e]).join(" ")+" "}update(t,[e]){var i,r;if(void 0===this._previousClasses){this._previousClasses=new Set,void 0!==t.strings&&(this._staticClasses=new Set(t.strings.join(" ").split(/\s/).filter(t=>""!==t)));for(const t in e)e[t]&&!(null==(i=this._staticClasses)?void 0:i.has(t))&&this._previousClasses.add(t);return this.render(e)}const o=t.element.classList;for(const a of this._previousClasses)a in e||(o.remove(a),this._previousClasses.delete(a));for(const a in e){const t=!!e[a];t===this._previousClasses.has(a)||(null==(r=this._staticClasses)?void 0:r.has(a))||(t?(o.add(a),this._previousClasses.add(a)):(o.remove(a),this._previousClasses.delete(a)))}return c}}),q=o`
  :host {
    display: inline-flex !important;
  }

  slot {
    width: 100%;
    display: inline-block;
    font-style: normal;
    font-family: var(--wui-font-family);
    font-feature-settings:
      'tnum' on,
      'lnum' on,
      'case' on;
    line-height: 130%;
    font-weight: var(--wui-font-weight-regular);
    overflow: inherit;
    text-overflow: inherit;
    text-align: var(--local-align);
    color: var(--local-color);
  }

  .wui-line-clamp-1 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }

  .wui-line-clamp-2 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .wui-font-medium-400 {
    font-size: var(--wui-font-size-medium);
    font-weight: var(--wui-font-weight-light);
    letter-spacing: var(--wui-letter-spacing-medium);
  }

  .wui-font-medium-600 {
    font-size: var(--wui-font-size-medium);
    letter-spacing: var(--wui-letter-spacing-medium);
  }

  .wui-font-title-600 {
    font-size: var(--wui-font-size-title);
    letter-spacing: var(--wui-letter-spacing-title);
  }

  .wui-font-title-6-600 {
    font-size: var(--wui-font-size-title-6);
    letter-spacing: var(--wui-letter-spacing-title-6);
  }

  .wui-font-mini-700 {
    font-size: var(--wui-font-size-mini);
    letter-spacing: var(--wui-letter-spacing-mini);
    text-transform: uppercase;
  }

  .wui-font-large-500,
  .wui-font-large-600,
  .wui-font-large-700 {
    font-size: var(--wui-font-size-large);
    letter-spacing: var(--wui-letter-spacing-large);
  }

  .wui-font-2xl-500,
  .wui-font-2xl-600,
  .wui-font-2xl-700 {
    font-size: var(--wui-font-size-2xl);
    letter-spacing: var(--wui-letter-spacing-2xl);
  }

  .wui-font-paragraph-400,
  .wui-font-paragraph-500,
  .wui-font-paragraph-600,
  .wui-font-paragraph-700 {
    font-size: var(--wui-font-size-paragraph);
    letter-spacing: var(--wui-letter-spacing-paragraph);
  }

  .wui-font-small-400,
  .wui-font-small-500,
  .wui-font-small-600 {
    font-size: var(--wui-font-size-small);
    letter-spacing: var(--wui-letter-spacing-small);
  }

  .wui-font-tiny-400,
  .wui-font-tiny-500,
  .wui-font-tiny-600 {
    font-size: var(--wui-font-size-tiny);
    letter-spacing: var(--wui-letter-spacing-tiny);
  }

  .wui-font-micro-700,
  .wui-font-micro-600 {
    font-size: var(--wui-font-size-micro);
    letter-spacing: var(--wui-letter-spacing-micro);
    text-transform: uppercase;
  }

  .wui-font-tiny-400,
  .wui-font-small-400,
  .wui-font-medium-400,
  .wui-font-paragraph-400 {
    font-weight: var(--wui-font-weight-light);
  }

  .wui-font-large-700,
  .wui-font-paragraph-700,
  .wui-font-micro-700,
  .wui-font-mini-700 {
    font-weight: var(--wui-font-weight-bold);
  }

  .wui-font-medium-600,
  .wui-font-medium-title-600,
  .wui-font-title-6-600,
  .wui-font-large-600,
  .wui-font-paragraph-600,
  .wui-font-small-600,
  .wui-font-tiny-600,
  .wui-font-micro-600 {
    font-weight: var(--wui-font-weight-medium);
  }

  :host([disabled]) {
    opacity: 0.4;
  }
`;var N=globalThis&&globalThis.__decorate||function(t,e,i,r){var o,a=arguments.length,s=a<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(t,e,i,r);else for(var n=t.length-1;n>=0;n--)(o=t[n])&&(s=(a<3?o(s):a>3?o(e,i,s):o(e,i))||s);return a>3&&s&&Object.defineProperty(e,i,s),s};let Y=class extends s{constructor(){super(...arguments),this.variant="paragraph-500",this.color="fg-300",this.align="left",this.lineClamp=void 0}render(){const t={[`wui-font-${this.variant}`]:!0,[`wui-color-${this.color}`]:!0,[`wui-line-clamp-${this.lineClamp}`]:!!this.lineClamp};return this.style.cssText=`\n      --local-align: ${this.align};\n      --local-color: var(--wui-color-${this.color});\n    `,n`<slot class=${G(t)}></slot>`}};Y.styles=[a,q],N([v()],Y.prototype,"variant",void 0),N([v()],Y.prototype,"color",void 0),N([v()],Y.prototype,"align",void 0),N([v()],Y.prototype,"lineClamp",void 0),Y=N([u("wui-text")],Y);const J=o`
  :host {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    position: relative;
    overflow: hidden;
    background-color: var(--wui-color-gray-glass-020);
    border-radius: var(--local-border-radius);
    border: var(--local-border);
    box-sizing: content-box;
    width: var(--local-size);
    height: var(--local-size);
    min-height: var(--local-size);
    min-width: var(--local-size);
  }

  @supports (background: color-mix(in srgb, white 50%, black)) {
    :host {
      background-color: color-mix(in srgb, var(--local-bg-value) var(--local-bg-mix), transparent);
    }
  }
`;var K=globalThis&&globalThis.__decorate||function(t,e,i,r){var o,a=arguments.length,s=a<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(t,e,i,r);else for(var n=t.length-1;n>=0;n--)(o=t[n])&&(s=(a<3?o(s):a>3?o(e,i,s):o(e,i))||s);return a>3&&s&&Object.defineProperty(e,i,s),s};let Q=class extends s{constructor(){super(...arguments),this.size="md",this.backgroundColor="accent-100",this.iconColor="accent-100",this.background="transparent",this.border=!1,this.borderColor="wui-color-bg-125",this.icon="copy"}render(){const t=this.iconSize||this.size,e="lg"===this.size,i="xl"===this.size,r=e?"12%":"16%",o=e?"xxs":i?"s":"3xl",a="gray"===this.background,s="opaque"===this.background,l="accent-100"===this.backgroundColor&&s||"success-100"===this.backgroundColor&&s||"error-100"===this.backgroundColor&&s||"inverse-100"===this.backgroundColor&&s;let c=`var(--wui-color-${this.backgroundColor})`;return l?c=`var(--wui-icon-box-bg-${this.backgroundColor})`:a&&(c=`var(--wui-color-gray-${this.backgroundColor})`),this.style.cssText=`\n       --local-bg-value: ${c};\n       --local-bg-mix: ${l||a?"100%":r};\n       --local-border-radius: var(--wui-border-radius-${o});\n       --local-size: var(--wui-icon-box-size-${this.size});\n       --local-border: ${"wui-color-bg-125"===this.borderColor?"2px":"1px"} solid ${this.border?`var(--${this.borderColor})`:"transparent"}\n   `,n` <wui-icon color=${this.iconColor} size=${t} name=${this.icon}></wui-icon> `}};Q.styles=[a,h,J],K([v()],Q.prototype,"size",void 0),K([v()],Q.prototype,"backgroundColor",void 0),K([v()],Q.prototype,"iconColor",void 0),K([v()],Q.prototype,"iconSize",void 0),K([v()],Q.prototype,"background",void 0),K([v({type:Boolean})],Q.prototype,"border",void 0),K([v()],Q.prototype,"borderColor",void 0),K([v()],Q.prototype,"icon",void 0),Q=K([u("wui-icon-box")],Q);const X=o`
  :host {
    display: block;
    width: var(--local-width);
    height: var(--local-height);
  }

  img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
    border-radius: inherit;
  }
`;var Z=globalThis&&globalThis.__decorate||function(t,e,i,r){var o,a=arguments.length,s=a<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(t,e,i,r);else for(var n=t.length-1;n>=0;n--)(o=t[n])&&(s=(a<3?o(s):a>3?o(e,i,s):o(e,i))||s);return a>3&&s&&Object.defineProperty(e,i,s),s};let tt=class extends s{constructor(){super(...arguments),this.src="./path/to/image.jpg",this.alt="Image",this.size=void 0}render(){return this.style.cssText=`\n      --local-width: ${this.size?`var(--wui-icon-size-${this.size});`:"100%"};\n      --local-height: ${this.size?`var(--wui-icon-size-${this.size});`:"100%"};\n      `,n`<img src=${this.src} alt=${this.alt} @error=${this.handleImageError} />`}handleImageError(){this.dispatchEvent(new CustomEvent("onLoadError",{bubbles:!0,composed:!0}))}};tt.styles=[a,p,X],Z([v()],tt.prototype,"src",void 0),Z([v()],tt.prototype,"alt",void 0),Z([v()],tt.prototype,"size",void 0),tt=Z([u("wui-image")],tt);const et=o`
  :host {
    display: flex;
    justify-content: center;
    align-items: center;
    height: var(--wui-spacing-m);
    padding: 0 var(--wui-spacing-3xs) !important;
    border-radius: var(--wui-border-radius-5xs);
    transition:
      border-radius var(--wui-duration-lg) var(--wui-ease-out-power-1),
      background-color var(--wui-duration-lg) var(--wui-ease-out-power-1);
    will-change: border-radius, background-color;
  }

  :host > wui-text {
    transform: translateY(5%);
  }

  :host([data-variant='main']) {
    background-color: var(--wui-color-accent-glass-015);
    color: var(--wui-color-accent-100);
  }

  :host([data-variant='shade']) {
    background-color: var(--wui-color-gray-glass-010);
    color: var(--wui-color-fg-200);
  }

  :host([data-variant='success']) {
    background-color: var(--wui-icon-box-bg-success-100);
    color: var(--wui-color-success-100);
  }

  :host([data-variant='error']) {
    background-color: var(--wui-icon-box-bg-error-100);
    color: var(--wui-color-error-100);
  }

  :host([data-size='lg']) {
    padding: 11px 5px !important;
  }

  :host([data-size='lg']) > wui-text {
    transform: translateY(2%);
  }
`;var it=globalThis&&globalThis.__decorate||function(t,e,i,r){var o,a=arguments.length,s=a<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(t,e,i,r);else for(var n=t.length-1;n>=0;n--)(o=t[n])&&(s=(a<3?o(s):a>3?o(e,i,s):o(e,i))||s);return a>3&&s&&Object.defineProperty(e,i,s),s};let rt=class extends s{constructor(){super(...arguments),this.variant="main",this.size="lg"}render(){this.dataset.variant=this.variant,this.dataset.size=this.size;const t="md"===this.size?"mini-700":"micro-700";return n`
      <wui-text data-variant=${this.variant} variant=${t} color="inherit">
        <slot></slot>
      </wui-text>
    `}};rt.styles=[a,et],it([v()],rt.prototype,"variant",void 0),it([v()],rt.prototype,"size",void 0),rt=it([u("wui-tag")],rt);const ot=o`
  :host {
    display: flex;
  }

  :host([data-size='sm']) > svg {
    width: 12px;
    height: 12px;
  }

  :host([data-size='md']) > svg {
    width: 16px;
    height: 16px;
  }

  :host([data-size='lg']) > svg {
    width: 24px;
    height: 24px;
  }

  :host([data-size='xl']) > svg {
    width: 32px;
    height: 32px;
  }

  svg {
    animation: rotate 2s linear infinite;
  }

  circle {
    fill: none;
    stroke: var(--local-color);
    stroke-width: 4px;
    stroke-dasharray: 1, 124;
    stroke-dashoffset: 0;
    stroke-linecap: round;
    animation: dash 1.5s ease-in-out infinite;
  }

  :host([data-size='md']) > svg > circle {
    stroke-width: 6px;
  }

  :host([data-size='sm']) > svg > circle {
    stroke-width: 8px;
  }

  @keyframes rotate {
    100% {
      transform: rotate(360deg);
    }
  }

  @keyframes dash {
    0% {
      stroke-dasharray: 1, 124;
      stroke-dashoffset: 0;
    }

    50% {
      stroke-dasharray: 90, 124;
      stroke-dashoffset: -35;
    }

    100% {
      stroke-dashoffset: -125;
    }
  }
`;var at=globalThis&&globalThis.__decorate||function(t,e,i,r){var o,a=arguments.length,s=a<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(t,e,i,r);else for(var n=t.length-1;n>=0;n--)(o=t[n])&&(s=(a<3?o(s):a>3?o(e,i,s):o(e,i))||s);return a>3&&s&&Object.defineProperty(e,i,s),s};let st=class extends s{constructor(){super(...arguments),this.color="accent-100",this.size="lg"}render(){return this.style.cssText="--local-color: "+("inherit"===this.color?"inherit":`var(--wui-color-${this.color})`),this.dataset.size=this.size,n`<svg viewBox="25 25 50 50">
      <circle r="20" cy="50" cx="50"></circle>
    </svg>`}};st.styles=[a,ot],at([v()],st.prototype,"color",void 0),at([v()],st.prototype,"size",void 0),st=at([u("wui-loading-spinner")],st);export{L as A,_ as U,G as a,u as c,j as d,T as i,v as p,f as s};
